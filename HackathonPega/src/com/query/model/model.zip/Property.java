package com.query.model;

public interface Property {
	
	public String name();
	
	public String type();
	
	public String expression();
}
